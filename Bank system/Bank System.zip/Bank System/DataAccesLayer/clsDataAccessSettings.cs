﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccesLayer
{
    public static class clsDataAccessSettings
    {
        public static string ConnectionString = "server=.;Database = Bankdb;User Id = sa;Password = sa123456;";
    }
}
